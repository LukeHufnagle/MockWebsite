function remove(){
    document.querySelector(".cookiePop").remove()
}

function changeImage(){
    document.getElementById("mainAloePic").src = "assets/succulents-2.jpg"
}

function changeImage2(){
    document.getElementById("mainAloePic").src = "assets/succulents-1.jpg"
}